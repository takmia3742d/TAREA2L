<?php
//CHUMBILE  
require_once(__DIR__ . '/layout/header.php');
require_once(__DIR__ . '/connection/BaseMySQL.php');
require_once(__DIR__ . '/database/CoursesDB.php');

$cnx = BaseMySql::conexion();
$coursesDB = new CoursesDB();
$data = $coursesDB->agrupar($cnx);

BaseMySql::close($cnx);

?>

<div class="container mt-5">
    <h2 class="mb-4">Cursos agrupados por Profesor</h2>

    <table class="table table-bordered table-striped">
        <thead class="table-primary">
            <tr>
                <th>Profesor</th>
                <th>Departamento</th>
                <th>Total Cursos</th>
            </tr>
        </thead>
        <tbody>
    
            <?php foreach ($data as $fila): ?> 
                    <tr>
                        <td><?= htmlspecialchars($fila->professor_name) ?></td>
                        <td><?= htmlspecialchars($fila->department_name) ?></td>
                        <td><?= htmlspecialchars($fila->total_cursos) ?></td>
                    </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once(__DIR__ . '/layout/footer.php'); ?>
