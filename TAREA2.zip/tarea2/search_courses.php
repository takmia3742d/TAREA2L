<?php
//RUIZ CARLOS  require_once('./model/BaseMySQL.php');
require_once('./model/DepartmentsDB.php');
require_once('./model/CoursesDB.php');

$cnx = BaseMySQL::conectar();
$departmentsDB = new DepartmentsDB();
$coursesDB = new CoursesDB();

$departments = $departmentsDB->listar($cnx);

$courses = [];
$selected_department = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['department_id'])) {
    $selected_department = $_POST['department_id'];
 }

BaseMySQL::close($cnx);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Cursos por Departamento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Buscar Cursos por Departamento</h2>
    <form method="post" class="mb-4">
        <div class="row g-3 align-items-center">
            <div class="col-auto">
                <label for="department_id" class="col-form-label">Departamento:</label>
            </div>
            <div class="col-auto">
                <select class="form-select" id="department_id" name="department_id" required>
                    <option value="" disabled <?= is_null($selected_department) ? 'selected' : '' ?>>Seleccione un departamento</option>
                    <?php foreach ($departments as $dep): ?>
                        <option value="<?= htmlspecialchars($dep['department_id']) ?>" 
                            <?= ($selected_department == $dep['department_id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($dep['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
        </div>
    </form>

    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <h4 class="mt-4">Resultados:</h4>
        <?php if (count($courses) > 0): ?>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID Curso</th>
                        <th>Nombre del Curso</th>
                        <th>Créditos</th>
                        <th>Profesor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?= htmlspecialchars($course['course_id']) ?></td>
                            <td><?= htmlspecialchars($course['course_name']) ?></td>
                            <td><?= htmlspecialchars($course['credits']) ?></td>
                            <td><?= htmlspecialchars($course['professor_name']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-warning mt-3">No se encontraron cursos para este departamento.</div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
