<?php
/* Realizado por Vidal Azañero 7/05/2025*/
class Courses
{
    private $_course_id;
    private $_name;
    private $_credits;
    private $_professor_id;

    public function __construct($name, $credits, $professor_id, $course_id = null)
    {
        $this->_course_id = $course_id;
        $this->_name = $name;
        $this->_credits = $credits;
        $this->_professor_id = $professor_id;
    }
    public function getCourseId()
    {
        return $this->_course_id;
    }
    public function getCourseName()
    {
        return $this->_name;
    }
    public function getCredits()
    {
        return $this->_credits;
    }
    public function getProfessorId()
    {
        return $this->_professor_id;
    }
    public function setCourseId($course_id)
    {
        $this->_course_id = $course_id;
    }
    public function setCourseName($name)
    {
        $this->_name = $name;
    }
    public function setCredits($credits)
    {
        $this->_credits = $credits;
    }
    public function setProfessorId($professor_id)
    {
        $this->_professor_id = $professor_id;
    }
}
?>
