<?php
//RUIZ CARLOS 7/05/2025
require_once(__DIR__ . '/layout/header.php');
require_once(__DIR__ . '/connection/BaseMySQL.php');
require_once(__DIR__ . '/database/ProfessorsDB.php');
require_once(__DIR__ . '/database/CoursesDB.php');
require_once(__DIR__ . '/model/Courses.php');

$cnx = BaseMySql::conexion();
$professorsDB = new ProfessorsDB();
$professors = $professorsDB->nombres($cnx);

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $credits = (int) $_POST['credits'];
    $professor_id = (int) $_POST['professor_id'];

    if ($name && $credits >= 1 && $professor_id) {
        $curso_new = new Courses($name, $credits, $professor_id);
        $coursesDB = new CoursesDB();
        $success = $coursesDB->insertar($cnx, $curso_new);
        if (!$success) {
            $error = 'Error al registrar el curso.';
        }
    } else {
        $error = 'Por favor complete todos los campos correctamente.';
    }
}
?>

<div class="container mt-5">
    <h2 class="mb-4">Registrar Nuevo Curso</h2>

    <?php if ($success): ?>
        <div class="alert alert-success">Curso registrado correctamente.</div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="mb-3">
            <label for="name" class="form-label">Nombre del Curso</label>
            <input type="text" class="form-control" id="name" name="name" maxlength="100" required>
        </div>
        <div class="mb-3">
            <label for="credits" class="form-label">Créditos</label>
            <input type="number" class="form-control" id="credits" name="credits" min="1" required>
        </div>
        <div class="mb-3">
            <label for="professor_id" class="form-label">Profesor</label>
            <select class="form-select" id="professor_id" name="professor_id" required>
                <option value="" disabled selected>Seleccione un profesor</option>
                <?php foreach ($professors as $professor): ?>
                    <option value="<?= htmlspecialchars($professor->professor_id) ?>">
                        <?= htmlspecialchars($professor->name) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Guardar Curso</button>
    </form>
</div>

<?php require_once(__DIR__ . '/layout/footer.php'); ?>
