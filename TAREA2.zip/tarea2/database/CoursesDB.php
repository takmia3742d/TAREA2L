<?php
/* Realizado por Vidal Azañero 7/05/2025*/
require_once('./model/Courses.php');
require_once('./model/Professors.php');
class CoursesDB
{
    public function insertar($cnx, $curso_new)
    {
        try {
            $query = "INSERT INTO courses (name, credits, professor_id)
                      VALUES (:name, :credits, :professor_id)";
            $stmt = $cnx->prepare($query);
            $stmt->bindValue(':name', $curso_new->getCourseName(), PDO::PARAM_STR);
            $stmt->bindValue(':credits', $curso_new->getCredits(), PDO::PARAM_INT);
            $stmt->bindValue(':professor_id', $curso_new->getProfessorId(), PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $error) {
            file_put_contents('error_log.txt', $error->getMessage(), FILE_APPEND);
            echo '<h2>No fue posible insertar en la base de datos. Por favor, intente nuevamente más tarde.</h2>';
            return false;
        }
    }

    public function listarC($cnx)
    {
        try {
            if ($cnx) {
                $query = "
                    SELECT c.course_id, c.name AS course_name, c.credits, p.name AS professor_name, d.name AS department_name
                    FROM courses c
                    INNER JOIN professors p ON c.professor_id = p.professor_id
                    LEFT JOIN departments d ON p.department_id = d.department_id
                ";
                $stmt = $cnx->prepare($query);
                $stmt->execute();
                $stmt->setFetchMode(PDO::FETCH_OBJ);
                return $stmt->fetchAll();
            } else {
                throw new Exception('No se pudo establecer la conexión a la base de datos');
            }
        } catch (PDOException $error) {
            file_put_contents('error_log.txt', $error->getMessage(), FILE_APPEND);
            echo '<h2>No fue posible obtener los cursos. Por favor, intente nuevamente más tarde.</h2>';
            return [];
        } catch (Exception $error) {
            file_put_contents('error_log.txt', $error->getMessage(), FILE_APPEND);
            echo '<h2>' . $error->getMessage() . '</h2>';
            return [];
        }
    }

    public function agrupar($cnx)
    {
        try {
            if ($cnx) {
                $query = "
                    SELECT p.professor_id, p.name AS professor_name, d.name AS department_name,
                           COUNT(c.course_id) AS total_cursos
                    FROM professors p
                    JOIN departments d ON p.department_id = d.department_id
                    LEFT JOIN courses c ON c.professor_id = p.professor_id
                    GROUP BY p.professor_id, p.name, d.name
                    ORDER BY p.name ASC
                ";
                $stmt = $cnx->prepare($query);
                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_OBJ);
            } else {
                throw new Exception('No se pudo establecer la conexión a la base de datos');
            }
        } catch (PDOException $error) {
            file_put_contents('error_log.txt', $error->getMessage(), FILE_APPEND);
            echo '<h2>No fue posible obtener los datos agrupados. Por favor, intente nuevamente más tarde.</h2>';
            return [];
        } catch (Exception $error) {
            file_put_contents('error_log.txt', $error->getMessage(), FILE_APPEND);
            echo '<h2>' . $error->getMessage() . '</h2>';
            return [];
        }
    }
}
?>