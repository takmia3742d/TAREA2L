<?php
/* Realizado por Vidal Azañero 7/05/2025*/
require_once('./model/Professors.php');
require_once('./model/Departments.php');
class ProfessorsDB
{
    public function listar($cnx)
    {
        $query = "
            SELECT p.name, p.email, d.name AS department_name
            FROM professors p
            JOIN departments d ON p.department_id = d.department_id
        ";
        $stmt = $cnx->prepare($query);
        $stmt->execute();
        $profesores = $stmt->fetchAll(PDO::FETCH_OBJ); 
        return $profesores;
    }

    public function nombres($cnx)
    {
        $query = "
            SELECT professor_id, name FROM professors ORDER BY name ASC
        ";
        $stmt = $cnx->prepare($query);
        $stmt->execute();
        $names = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $names;
    }
}
?>
