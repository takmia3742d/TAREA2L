<?php
/* Realizado por Vidal Azañero 
Fecha: 2025-05-07*/
require_once('./model/Departments.php');
require_once('./model/Courses.php');
require_once('./model/Professors.php');
class DepartmentsDB
{
    public function depar($cnx)
    {
        $query = "
            SELECT department_id, name FROM departments
        ";
        $stmt = $cnx->prepare($query);
        $stmt->execute();
        $departamentos = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $departamentos;
    }
    public function buscar($cnx, $departamentoId)
{
    try {
        $query = "
            SELECT c.id, c.name AS curso, c.credits, p.name AS profesor
                FROM courses c
                INNER JOIN professors p ON p.id = c.professor_id
                WHERE c.department_id = :department_id
            ";
        $stmt = $cnx->prepare($query);
        $stmt->bindValue(':departamento_id', $departamentoId, PDO::PARAM_INT);
        $stmt->execute();
        $cursos = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $cursos;
    } catch (PDOException $error) {
        echo '<h2>No fue posible consultar la base de datos: ' . $error->getMessage() . '</h2>';
        return [];
    }
}
}
?>