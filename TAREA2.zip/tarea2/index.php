<?php include('./layout/header.php'); ?>
<!--Ruiz Carlos
Fecha: 2025-05-07
-->
<h1>Bienvenido al sistema</h1>
<p>Este es el contenido de prueba de tu aplicación.</p><br>

<?php include('./layout/footer.php'); ?>