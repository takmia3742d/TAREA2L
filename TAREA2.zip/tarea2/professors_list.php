<?php
//RUIZ CARLOS  

require_once(__DIR__ . '/layout/header.php');
require_once(__DIR__ . '/connection/BaseMySQL.php');
require_once(__DIR__ . '/database/ProfessorsDB.php');

$cnx = BaseMySql::conexion();
$db = new ProfessorsDB();
$professors = $db->listar($cnx);
BaseMySql::close($cnx);
?>
<div class="container mt-5">
    <h2 class="mb-4">Listado de Profesores</h2>
    <table class="table table-striped table-bordered">
        <thead class="table-primary">
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Departamento</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($professors as $professor): ?>
                <tr>
                    <td><?= htmlspecialchars($professor->name) ?></td>
                    <td><?= htmlspecialchars($professor->email) ?></td>
                    <td><?= htmlspecialchars($professor->department_name) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>





<!--Ruiz Carlos
Fecha: 2025-05-07
-->
<?php require_once(__DIR__ . '/layout/footer.php'); ?>
