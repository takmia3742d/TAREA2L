<?php
//RUIZ CARLOS  CON AYUDA DE CHUMBILE 7/05/025
require_once(__DIR__ . '/layout/header.php');
require_once(__DIR__ . '/connection/BaseMySQL.php');
require_once(__DIR__ . '/database/CoursesDB.php');

$cnx = BaseMySql::conexion();
$coursesDB = new CoursesDB();
$courses = $coursesDB->listarC($cnx);
BaseMySql::close($cnx);
?>

<div class="mb-3 d-flex justify-content-end">
    <a href="course_new.php" class="btn btn-success me-2">Agregar</a>
    <a href="search_courses.php" class="btn btn-info">Buscar por departamento</a>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-primary">
        <tr>
            <th>Nombre del Curso</th>
            <th>Créditos</th>
            <th>Profesor</th>
            <th>Departamento</th>
        </tr>
    </thead>
    
    <tbody>
        <?php if (!empty($courses)): ?>
            <?php foreach ($courses as $course): ?>
                <tr>
                    <td><?= htmlspecialchars($course->course_name) ?></td>
                    <td><?= htmlspecialchars($course->credits) ?></td>
                    <td><?= htmlspecialchars($course->professor_name) ?></td>
                    <td><?= htmlspecialchars($course->department_name) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No se encontraron cursos registrados.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once(__DIR__ . '/layout/footer.php'); ?>